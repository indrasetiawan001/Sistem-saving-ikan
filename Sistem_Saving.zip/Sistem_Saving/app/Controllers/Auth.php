<?php namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
{
    // Debug 1: Cek request method
    if ($this->request->getMethod() !== 'post') {
        return view('auth/login');
    }

    // Debug 2: Cek data input
    $post = $this->request->getPost();
    log_message('debug', 'Login attempt: '.print_r($post, true));

    // Validasi
    $rules = [
        'username' => 'required',
        'password' => 'required|min_length[6]'
    ];

    if (!$this->validate($rules)) {
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Cek user
    $model = new UserModel();
    $user = $model->where('username', $post['username'])->first();

    if (!$user) {
        log_message('error', 'User not found: '.$post['username']);
        return redirect()->back()->withInput()->with('error', 'Username tidak ditemukan');
    }

    // Verifikasi password
    if (!password_verify($post['password'], $user['password'])) {
        log_message('error', 'Wrong password for user: '.$user['username']);
        return redirect()->back()->withInput()->with('error', 'Password salah');
    }

    // Set session
    $sessionData = [
        'user_id'    => $user['id'],
        'username'   => $user['username'],
        'role'       => $user['role'],
        'logged_in'  => true
    ];
    session()->set($sessionData);

    // Debug 3: Cek session
    log_message('debug', 'Session data: '.print_r($_SESSION, true));

    // Redirect berdasarkan role
    $roleRedirect = [
        'petugas_tpi' => '/petugas',
        'admin_hnsi'  => '/admin',
        'kepala_hnsi' => '/kepala',
        'nelayan'     => '/member',
        'bakul'       => '/member'
    ];

    return redirect()->to($roleRedirect[$user['role']] ?? '/dashboard');
}
}