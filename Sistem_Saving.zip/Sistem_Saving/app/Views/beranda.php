<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .stat-card {
            border-radius: 10px;
            transition: transform 0.3s;
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 2rem;
            opacity: 0.8;
        }
        
        .recent-transactions {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .transaction-item {
            border-left: 4px solid var(--secondary-color);
            transition: all 0.3s;
        }
        
        .transaction-item:hover {
            background-color: #f1f8ff;
            border-left-color: var(--accent-color);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: var(--primary-color)">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-fish me-2"></i>SIPELANG - HNSI
            </a>
            <div class="d-flex">
                <span class="text-white me-3">
                    <i class="bi bi-calendar-date me-1"></i>
                    <?= date('d F Y') ?>
                </span>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container py-4">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">
                <i class="bi bi-speedometer2 me-2"></i>Dashboard
            </h2>
            <div class="badge bg-primary p-2">
                <i class="bi bi-info-circle me-1"></i>Mode Pengembangan
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card card bg-white p-3">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="text-muted mb-2">Total Transaksi</h6>
                            <h3 class="mb-0"><?= $stats['total_transaksi'] ?></h3>
                        </div>
                        <div class="stat-icon text-primary">
                            <i class="bi bi-receipt"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card card bg-white p-3">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="text-muted mb-2">Total Nelayan</h6>
                            <h3 class="mb-0"><?= $stats['total_nelayan'] ?></h3>
                        </div>
                        <div class="stat-icon text-success">
                            <i class="bi bi-people"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card card bg-white p-3">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="text-muted mb-2">Total Bakul</h6>
                            <h3 class="mb-0"><?= $stats['total_bakul'] ?></h3>
                        </div>
                        <div class="stat-icon text-warning">
                            <i class="bi bi-shop"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card card bg-white p-3">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="text-muted mb-2">Omset Bulanan</h6>
                            <h3 class="mb-0"><?= $stats['omset_bulanan'] ?></h3>
                        </div>
                        <div class="stat-icon text-danger">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Transactions -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">
                    <i class="bi bi-clock-history me-2"></i>Transaksi Terakhir
                </h5>
            </div>
            <div class="card-body recent-transactions">
                <?php foreach($recent_transactions as $trx): ?>
                <div class="transaction-item p-3 mb-2 bg-white rounded">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1"><?= $trx['id'] ?></h6>
                            <small class="text-muted">Nelayan: <?= $trx['nelayan'] ?></small>
                        </div>
                        <div class="text-end">
                            <strong class="d-block"><?= $trx['total'] ?></strong>
                            <small class="text-muted"><?= $trx['tanggal'] ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <h5 class="mb-0">
                    <i class="bi bi-lightning me-2"></i>Aksi Cepat
                </h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-3">
                        <button class="btn btn-outline-primary w-100 py-2">
                            <i class="bi bi-plus-circle me-1"></i>Tambah Transaksi
                        </button>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-outline-success w-100 py-2">
                            <i class="bi bi-person-plus me-1"></i>Daftar Nelayan
                        </button>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-outline-warning w-100 py-2">
                            <i class="bi bi-graph-up me-1"></i>Laporan
                        </button>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-outline-danger w-100 py-2">
                            <i class="bi bi-gear me-1"></i>Pengaturan
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-3 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><i class="bi bi-fish me-2"></i>SIPELANG</h5>
                    <p>Sistem Informasi Pelelangan Ikan HNSI</p>
                </div>
                <div class="col-md-6 text-end">
                    <p class="mb-0">
                        &copy; <?= date('Y') ?> - Versi 1.0.0
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Animasi saat load
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.stat-card');
            cards.forEach((card, index) => {
                setTimeout(() => {
                    card.style.opacity = 1;
                }, 100 * index);
            });
        });
    </script>
</body>
</html>